import dados2 from "../jogo/jogos.json" with {type: "json"};
import * as Jogos from "../jogo/jogos.js";

const criarLink = (texto, link) => {
    const a = document.createElement('a');
    a.textContent = texto;
    a.setAttribute('href', link);
    a.setAttribute('data-link', '');
    return a;
}
const sobre = () => {
    const divSobre = document.createElement('div');
    const paragrafo = document.createElement('p');
    paragrafo.textContent = "Sobre";

    divSobre.appendChild(paragrafo);
    return divSobre;
}
const criaHeader = () => {
    const header = document.createElement('header')
    const div = document.createElement('div')
    div.classList.add('logo')
    div.textContent = 'STEAM';

    const nav = document.createElement('nav')
    nav.setAttribute('id', 'subnav')

    const a1 = criarLink('Loja', '/loja')
    const a2 = criarLink('Comunidade', '/comunidade')
    const a3 = criarLink('Jogos', '/jogos')
    const a4 = criarLink('Sobre', '/sobre')
    const a6 = criarLink('Instalar Steam', '#')
    a6.classList.add('btn-nav');

    header.appendChild(div)
    header.appendChild(nav)
    nav.appendChild(a1)
    nav.appendChild(a2)
    nav.appendChild(a3)
    nav.appendChild(a4)

    nav.appendChild(a6)

    return header;
}

const criaSecaoDeJogo = (h1Param, pParam, img) => {
    const divJogoContent = document.createElement("div");
    divJogoContent.classList.add("jogo-content");

    const divjogoInfo = document.createElement("div");
    divjogoInfo.classList.add("jogo-info");

    const divjogoBotao = document.createElement("div");
    divjogoInfo.classList.add("div-botao");

    const h1 = document.createElement("h1");
    h1.textContent = h1Param;

    const paragrafo = document.createElement("p");
    paragrafo.textContent = pParam;
    paragrafo.classList.add("paragrafo-secao-jogo");

    const divImagem = document.createElement("div");
    divImagem.classList.add("jogo-imagem");

    const botao = document.createElement("button");
    botao.textContent = "Comprar NOME DO JOGO";
    botao.classList.add("cta");

    const imagem = document.createElement("img");
    imagem.src = img;
    imagem.width = 700;

    divJogoContent.appendChild(divjogoInfo);
    divjogoInfo.appendChild(h1);
    divjogoInfo.appendChild(paragrafo);
    divImagem.appendChild(imagem);
    divjogoBotao.appendChild(botao);
    divjogoInfo.appendChild(divImagem);
    divjogoInfo.appendChild(divjogoBotao);

    return divJogoContent;
}

const criaContato = () => {
    const obj = document.createElement('section');
    obj.innerHTML = `<section class="contact">
        <h2>Receba Ofertas Exclusivas</h2>
        <form>
            <input type="text" placeholder="Seu Nome" required>
            <input type="email" placeholder="Seu Email" required>
            <button type="submit">Cadastrar</button>
        </form>
    </section>`
    return obj;
}
const criaFooter = () => {
    const obj = document.createElement('section');
    obj.innerHTML = `<footer>
         <p>Página Desenvolvida para Aula de Front-End II </p>
     </footer>`
    return obj;
}
const criaLoja = () => {
    const obj = document.createElement('section');
    obj.innerHTML = `
         <p>pag loja</p>
    `
    return obj;
}
const criaSobre = () => {
    const obj = document.createElement('section');
    obj.innerHTML = `
         <p>pag sobre</p>
    `
    return obj;
}
const criaComunidade = () => {
    const obj = document.createElement('section');
    obj.innerHTML = `
         <p>pag comunidade</p>
    `
    return obj;
}
const initApps = () => {
    const root = document.getElementById("root");
    root.appendChild(criaHeader());
    root.appendChild(Jogos.criaHero());
    root.appendChild(Jogos.criaSecaoJogos());
    root.appendChild(criaContato());
    root.appendChild(criaFooter());
}

const initCorpo = () => {
    const div = document.createElement("div");

    div.appendChild(Jogos.criaHero());
    div.appendChild(Jogos.criaSecaoJogos());
    div.appendChild(criaContato());

    return div;
}

const initJogo = () => {
    const root = document.getElementById("root");

    const linkCss = document.createElement("link");
    linkCss.setAttribute("rel", "stylesheet");
    linkCss.setAttribute("href", "./componentes/app/app.css");
    document.head.appendChild(linkCss);

    root.appendChild(criaHeader());
    root.appendChild(criaSecaoDeJogo("NOME DO JOGO", "Grand Theft Auto V é um jogo eletrônico de ação e aventura desenvolvido pela Rockstar North e publicado pela Rockstar Games.", "https://cdn.akamai.steamstatic.com/steam/apps/271590/header.jpg"));
    root.appendChild(Jogos.criaHero());
    root.appendChild(Jogos.criaSecaoJogos());
    root.appendChild(criaContato());
    root.appendChild(criaFooter());
}

const app = document.getElementById("app");

const rotasComArrow = {
    "/index.html": {
        renderizar: function () {
            return `
        <h1>Home</h1>`}
    },

    "/loja": {
        renderizar: function () {
            return `
        <h1>Loja</h1>
        <p>Página Loja</p>`}
    },

    "/sobre": {
        renderizar: function () {
            return `
        <h1>sobre</h1>
        <p>Informações sobre o Sistema</p>`}
    },

    "/comunidade": {
        renderizar: function () {
            return `
         <h1>comunidade</h1>
        <p>Página comunidade</p>`}
    },
    "/jogos": {
        renderizar: function (id) {
            return `
         <h1>jogos</h1>
        <p>ID: ${id}</p>`
        }
    },
};


document.addEventListener("click", function (event) {

    const link = event.target.closest("[data-link]");

    if (link) {
        event.preventDefault();

        const novocaminho = link.getAttribute("href"); //pega href="/jogos/10"

        navegarPara(novocaminho);
    }
});

function renderizandoRotas(path) {
    app.innerHTML = "";
    let partes = path.split("/");
    const novoPath = "/" + partes[1];
    const id = Number(partes[2]);


    if (novoPath === "/jogos" && id) {
        const jogo = dados2.find(elemento => elemento.appid == id);
        if (jogo) {
            app.appendChild(
                criaSecaoDeJogo(
                    jogo.titulo,
                    jogo.descricao,
                    jogo.url_imagem
                )
            );
        } else {
            app.innerHTML = "<h1>Jogo não encontrado</h1>";
        }
        return;
    }

    if (novoPath === "/jogos") {
        app.appendChild(initCorpo());
        return;
    }

    const pagina = rotasComArrow[novoPath];
    if (pagina) {
        app.innerHTML = pagina.renderizar();
    } else {
        app.innerHTML = "<h1>404</h1>";
    }
}

function navegarPara(path) {
    history.pushState({}, "", path);
    renderizandoRotas(path);
}

window.addEventListener("popstate", function () {
    renderizandoRotas(window.location.pathname);
});

const init = () => {
    const root = document.getElementById("root");

    root.appendChild(criaHeader());
    root.appendChild(app);
    root.appendChild(criaFooter());

    renderizandoRotas(window.location.pathname);
};

init();



