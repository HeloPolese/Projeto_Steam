import dados from "./jogos.json" with {type: "json"};


const criaCard = (id, nome, desconto, url) => {

    const card = document.createElement("a");

    card.classList.add("game-card");

    card.setAttribute("href", `/jogos/${id}`);

    card.setAttribute("data-link", "");

    const imagem = document.createElement("div");
    imagem.classList.add("game-img");

    const img = document.createElement("img");

    img.src = url;

    img.width = 200;

    imagem.appendChild(img);

    const titulo = document.createElement("h3");
    titulo.textContent = nome;

    const p = document.createElement("p");
    p.textContent = desconto;

    card.appendChild(imagem);
    card.appendChild(titulo);
    card.appendChild(p);

    return card;
}


const criaCardAleatorio = () => {
    var ind = Math.floor(Math.random() * dados.length);
    let card = criaCard(dados[ind].appid, dados[ind].titulo, dados[ind].descricao, dados[ind].url_imagem);
    return card;
}

dados.filter(elemento => {
    if (elemento.desconto > 10) {
        console.log(elemento);
    }
});

export const criaSecaoJogos = () => {
    const secao = document.createElement('section');
    secao.classList.add('games');

    const h2 = document.createElement('h2')
    h2.textContent = "Jogos em Destaque";
  
    const div = document.createElement('div');
   
    div.classList.add('game-grid');
    div.setAttribute("id", "cardsGrid");

    dados.forEach((elemento) => {
        div.appendChild(criaCardAleatorio(elemento))
    });

    secao.appendChild(h2);
    secao.appendChild(div);

    return secao;
}

export const criaHero = (classes) => {
    const obj = document.createElement('section');

    obj.innerHTML = `<section class="hero">
        <div class="hero-content">
            <h1>Promoção de Verão Steam</h1>
            <p>Milhares de jogos com até 90% de deconto. Não perca essa oportunidade!</p>
            <button class="cta">Explorar Ofertas</button>
        </div>
    </section>`
    return obj
}

const criaCardHTML = (nome, desconto, url) => {

    const card = document.createElement("div");
    card.innerHTML = `<div class="game-card">
                <div class="game-img">
                    <img data-id="2" src="${url}" width="200">
                </div>
                <h3>${nome}</h3>
                <p>${desconto}</p>
            </div>`

    return card;
}


